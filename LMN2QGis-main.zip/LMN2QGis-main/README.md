# LMN2QGis
Plugin allows for automatic project build needed for updating Forest Numerical Map and data management
